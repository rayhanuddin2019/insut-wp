<?php

if( class_exists( 'CSF' ) ) {

  //
  // Create a service widget
  //
  CSF::createWidget( 'insut_widget_mailchimp', array(
    'title'       => esc_html__( 'Insut Mailchimp', 'insut-essential' ),
    'classname'   => 'mailchimp-widget',
    'description' => esc_html__( 'Insut mailchip with social and contact', 'insut-essential' ),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
        ),

        array(
            'id'      => 'mailchimp_shortcode',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Mailchimp Shortcode' , 'insut-essential' ),
        ),
        array(
            'id'      => 'contact_title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Contact title' , 'insut-essential' ),
            'default'   =>  esc_html__( 'Give us a free call' , 'insut-essential' ),
        ),
        array(
            'id'      => 'contact_details',
            'type'    => 'textarea',
            'title'   =>  esc_html__( 'Contact details' , 'insut-essential' ),
            'default'   =>  esc_html__( '(+1) 800 456324 or (+1) 555 456325' , 'insut-essential' ),
        ),

        array(
            'id'     => 'social',
            'type'   => 'repeater',
            'title'   =>  esc_html__( 'Social links' , 'insut-essential' ),
            'fields' => array(
          
              array(
                'id'    => 'title',
                'type'  => 'text',
                'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
              ),

              array(
                'id'    => 'link',
                'type'  => 'text',
                'title'   =>  esc_html__( 'Link' , 'insut-essential' ),
              ),

              array(
                'id'    => 'icon',
                'type'  => 'icon',
                'title'   => esc_html__( 'Icon' , 'insut-essential' ),
             ),

          
            ),
          ),
          
    
    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'insut_widget_mailchimp' ) ) {
    function insut_widget_mailchimp( $args, $instance ) {
     
      echo $args['before_widget'];
    
      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }

      ?> 
      
            <?php if( $instance['mailchimp_shortcode'] !='' ): ?>
                <?php echo do_shortcode($instance['mailchimp_shortcode']); ?>  
            <?php endif; ?> 
             <?php if( $instance['contact_title'] !='' ): ?>
               <h5> <?php echo esc_html($instance['contact_title']); ?> </h5>
            <?php endif; ?> 
            <?php if( $instance['contact_details'] !='' ): ?>
               <p><?php echo esc_html($instance['contact_details']); ?> </p>
            <?php endif; ?> 
            <?php if( is_array( $instance['social'] ) ): ?>
              <div class="foo-socila">
                    <?php foreach( $instance['social'] as $item ): ?>
                        <a href="<?php echo esc_url($item['link']) ?>"><i class="<?php echo esc_attr($item['icon']) ?>"></i></a>
                    <?php endforeach; ?>
              </div>
            <?php endif; ?> 
     <?php
   

      echo $args['after_widget'];

    }
  }

}
