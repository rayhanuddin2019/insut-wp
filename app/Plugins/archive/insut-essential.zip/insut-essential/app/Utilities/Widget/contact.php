<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Create a Contact info
    //
    CSF::createWidget( 'insut_contact_widget', array(
      'title'       => esc_html__( 'Insut Contact Widget', 'insut-essential' ),
      'classname'   => 'about-widget',
      'description' => esc_html__( 'About us and contact info' , 'insut-essential' ),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
        ),
      
        array(
            'id'      => 'logo',
            'type'    => 'media',
            'title'   => esc_html__( 'Logo' , 'insut-essential' ),
            'library' => 'image',
          ),
        array(
            'id'      => 'link',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Link' , 'insut-essential' ),
        ),
        array(

          'id'      => 'content',
          'type'    => 'textarea',
          'title'   => esc_html__( 'Content' , 'insut-essential' ),
         
        ),

        array(

            'id'     => 'contact_info',
            'type'   => 'repeater',
            'title'   => esc_html__( 'Contact info' , 'insut-essential' ),
            'fields' => array(
          
                array(
                    'id'    => 'icon',
                    'type'  => 'icon',
                    'title'   => esc_html__( 'Icon' , 'insut-essential' ),
                ),
                
                array(
                    'id'      => 'title',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
                ),
                array(
                    'id'      => 'content',
                    'type'    => 'textarea',
                    'title'   =>  esc_html__( 'Content' , 'insut-essential' ),
                ),
            ),
        ),
  
      )
    ) );
  
    
    if( ! function_exists( 'insut_contact_widget' ) ) {
      function insut_contact_widget( $args, $instance ) {
  
        echo $args['before_widget'];
  
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }

        ?>
           <?php if($instance['logo']['url'] !=''): ?>
            <div class="foo-logo">
                <?php if($instance['link'] !=''): ?>
                    <a href="<?php echo esc_url($instance['link']); ?>"><img src="<?php echo esc_url($instance['logo']['url']); ?>" alt="<?php echo esc_attr($instance['title']); ?>"/></a>
                <?php else: ?> 
                    <img src="<?php echo esc_url($instance['logo']['url']); ?>" alt="<?php echo esc_attr($instance['title']); ?>"/>
                <?php endif; ?>
            </div>
            <?php endif; ?>
           <?php if($instance['content'] !=''): ?>
                <p>
                    <?php echo insut_kses($instance['content']); ?>
                </p>
           <?php endif; ?>
           <?php if(is_array( $instance['contact_info'])): ?>
                <?php foreach($instance['contact_info'] as $item): ?>
                    <div class="icon-box-03">
                        <i class=" <?php echo esc_attr($item['icon']) ?> "></i>
                        <span><?php echo esc_html($item['title']) ?></span>
                        <h5><?php echo esc_html($item['content']) ?></h5>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
       <?php
        echo $args['after_widget'];
  
      }
    }
  
  }
  