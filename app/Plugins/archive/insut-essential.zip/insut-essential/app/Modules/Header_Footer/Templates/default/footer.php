			<?php
				do_action( 'quomodo_footer_builder' );
				wp_footer();
			?>
		
	</body>
</html>
