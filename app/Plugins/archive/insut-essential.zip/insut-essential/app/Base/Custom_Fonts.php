<?php
namespace InsutEssential\Base;

/**
 * Fonts.
 * credited by Sabberworm
 */
class Custom_Fonts
{
     /**
	 * register default hooks and actions for WordPress
	 * @return
	 */
	public function register()
	{

        add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'insut_the_ico_fonts_icons' ) );
        add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'insut_the_ico_fonts_custom_icons' ) );
       
 
    }


    function insut_the_ico_fonts_custom_icons( $tabs = array()){
     
          // Append new icons
          $new_icons = [
              'insut-Icon5',
              'insut-Icon8',
              'insut-Icon9',
              'insut-Icon10',
              'insut-Icon12',
              'insut-Icon13',
              'insut-Icon14',
              'insut-Icon15',
              'insut-Icon16',
              'insut-Icon17',
              'insut-Icon18',
              'insut-Icon3',
              'insut-Icon4',
          ];
        
          $tabs['insut-custom-icon'] = array(
              'name'          => 'insut-custom-icon',
              'label'         => esc_html__( 'Insut Custom', 'insut' ),
              'labelIcon'     => 'insut-Icon17',
              'prefix'        => '',
              'displayPrefix' => 'insut',
              'url'           => INSUT_ESSENTIAL_CSS.'/insut-icon.css',
              'icons'         => $new_icons,
              'ver'           => '1.0.0',
          );
      
          return $tabs;
    }

    function insut_get_icons_lists() {
   
        $exclude_prefix  = '.icofont-';
        $exclude_prefix2 = ':before';
        $exclude_prefix3 = '::before';
        $exclude_prefix4 = '.';
        $exclude_prefix5 = ':root';
        $parse_icons      = new \Sabberworm\CSS\Parser(file_get_contents(INSUT_ESSENTIAL_CSS_DIR . '/icofont.min.css'));
        $parseDocument    = $parse_icons->parse();
        $data            = [];
      
        $pattern = "/class/i";
    
        foreach($parseDocument->getAllDeclarationBlocks() as $oBlock) {
            foreach($oBlock->getSelectors() as $oSelector) {
    
                if(!preg_match($pattern, $oSelector)){
    
                     $data[] = str_replace([$exclude_prefix, $exclude_prefix2,$exclude_prefix3,$exclude_prefix4,$exclude_prefix5], ['','', '','',''], $oSelector->getSelector()); 
               
                } 
               
            }
        }
    
        return $data;
    }

   

    function insut_the_ico_fonts_icons( $tabs = array() ) {

        // Append new icons
        $new_icons = $this->insut_get_icons_lists();
        
        $tabs['insut-icofont-icon'] = array(
            'name'          => 'insut-icofont-icon',
            'label'         => esc_html__( 'Ico Fonts', 'insut' ),
            'labelIcon'     => 'fas fa-user',
            'prefix'        => 'icofont-',
            'displayPrefix' => 'icofont',
            'url'           => INSUT_ESSENTIAL_CSS.'/icofont.min.css',
            'icons'         => $new_icons,
            'ver'           => '1.0.0',
        );
    
        return $tabs;
    }

}


