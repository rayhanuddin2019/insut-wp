<?php
namespace InsutEssential\Base\Repository;

class Post_Slider_Model extends Base_Modal{
   
    public function settings(){
           

      return $this->args;  
    }
}