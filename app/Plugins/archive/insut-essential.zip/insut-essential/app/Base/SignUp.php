<?php 
/**
 * @package  Appscres-essential
 */
namespace InsutEssential\Base;

use InsutEssential\Base\BaseController;

/**
* signup form widget
*/
class SignUp extends BaseController
{
	public function register() {
	
        add_action('init',[$this,'form_submit']);
    }
    
    function form_validate($data){

        unset($_SESSION["insut_reg_msg"]);
        //name
        if(isset($data['name']) && $data['name'] == ''){

            $_SESSION["insut_reg_msg"]['name'] = esc_html__('Name cannot be empty','insut-essential');
      
        }
        // username
        if(isset($data['username']) && $data['username'] == ''){

            $_SESSION["insut_reg_msg"]['username'] = esc_html__('UserName cannot be empty','insut-essential');
       
        }

        if(isset($data['username'])){

            if(username_exists($data['username'])){
                $_SESSION["insut_reg_msg"]['username'] = esc_html__('UserName already exist','insut-essential');
            }
          
        }
        // email
        if(isset($data['email']) && $data['email'] == ''){

            $_SESSION["insut_reg_msg"]['email'] = esc_html__('Email cannot be empty','insut-essential');
       
        }else{

            if ( !is_email( $data['email'] ) ) {
                $_SESSION["insut_reg_msg"]['valid_email'] = esc_html__('Email is not valid','insut-essential');
            }

            if ( email_exists( $data['email'] ) ) {
                $_SESSION["insut_reg_msg"]['exist_email'] = esc_html__('Email is already exist','insut-essential');
            }

        }

        //password
       
        if(isset($data['password']) && isset($data['cpassword'])){
           
            if( trim($data['password']) != trim($data['cpassword']) ){

                $_SESSION["insut_reg_msg"]['password'] = esc_html__('Password not macth','insut-essential');
           
            }
        }

        if(isset($_SESSION["insut_reg_msg"])){
            return true;
        }
        return false;
        
    }
   
    public function form_submit(){

        $retrieved_nonce = isset($_REQUEST['_wpnonce'])?$_REQUEST['_wpnonce']:'';

        if (!wp_verify_nonce($retrieved_nonce, 'insut_registration_action' ) ){
          return;  
        }

        session_start();
        $error =  $this->form_validate($_REQUEST); 
        if($error == false){
          $this->user_registration_form_completion($_REQUEST);   
        }  
        $request = $_SERVER["HTTP_REFERER"];
        wp_redirect($request); exit;

       

    }
	
    function user_registration_form_completion($data) {
        
            $userdata = array(
                'first_name' => $data['name'],
                'last_name'  => '',
                'user_login' => trim($data['username']),
                'user_email' => trim($data['email']),
                'user_pass'  => trim($data['password']),
            );
            $user = wp_insert_user( $userdata );
            
            if ( is_wp_error( $user  ) ) {
                $_SESSION["insut_reg_msg"]['submit_msg'] = $user->get_error_message();
            }

            $_SESSION["insut_reg_msg_success"] = esc_html__('Success','insut-essential');
       
    }

   
}