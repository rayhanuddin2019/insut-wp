<?php
/**
 * @package  Appscres-essential
 */
namespace InsutEssential\Base;

class Activate
{
	public static function activate() {
		flush_rewrite_rules();
	}
}