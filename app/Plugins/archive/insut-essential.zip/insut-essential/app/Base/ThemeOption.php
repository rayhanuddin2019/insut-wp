<?php 
/**
 * @package  Appscres-essential
 */
namespace InsutEssential\Base;

use InsutEssential\Base\BaseController;
use Carbon_Fields\Container;
use Carbon_Fields\Field;
/**
* 
*/
class ThemeOption extends BaseController
{
	public function register() {
        // admin
        
		add_action( 'carbon_fields_register_fields', array( $this, 'essential_attach_p_options' ) );
	}
	
	public function essential_attach_p_options() {
    
        Container::make( 'post_meta', 'Tranding' )
        ->where( 'post_type', '=', 'post' )
        ->set_context( 'side' )
        ->set_priority('high')
        ->add_fields( array(
            Field::make( 'select', 'insut_trending', __( 'Choose Options','insut' ) )
                ->set_options( 
                    array(
                    'no'  => esc_html__( 'No', 'insut-essential' ),
                    'yes' => esc_html__( 'Yes', 'insut-essential' ),
                
                ) 
            ),
           
        ));
    }
}