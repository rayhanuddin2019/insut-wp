<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class Quote_Service extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-quote-service';
    }

    public function get_title() {
        return esc_html__( 'Insut Quote Service', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Insut Service settings', 'insut-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'insut-essential' ),
					
				],
			]
        );

        $this->add_control(
            'template_id',
            [
                'label'     => esc_html__( 'Heading Content ', 'appscred-essential' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => '0',
                'options'   => $this->elementor_template(),
                'description' => esc_html__( 'Please select elementor templete from here, if not create elementor template from menu', 'insut-essential' ),
               
            ]
        );
        
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Custom Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
        
        $repeater->add_control(
            'list_service',
            [
                'label' => esc_html__( 'Service items', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'multiple' => true,
                'options' => $this->get_service_list(),
                
                'show_label' => true,
                'label_block' => true,
            ]
        );

		$repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
		);
    
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Service List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .qss-item' => 'text-align: {{VALUE}};',
                     

				],
			]
        );//Responsive control end

        $this->end_controls_section();

        do_action( 'insut_section_slider_tab', $this , $this->get_name()); 
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_control(
                    'title_hover_color', [

                        'label'     => esc_html__( 'Title Hover color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} a:hover .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

       
        $this->start_controls_section('appscred_item_icon_box_style',
            [
            'label' => esc_html__( 'Icon Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_box_color', [

                'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .qss-icon i' => 'color: {{VALUE}};',
                '{{WRAPPER}} .qss-icon svg path' => 'fill: {{VALUE}};',
                
                ],
            ]
        );

        $this->add_control(
            'icon_box_hv_color', [

                'label'     => esc_html__( 'Icon Hover Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .qss-item:hover .qss-icon i  ' => 'color: {{VALUE}};',
                '{{WRAPPER}} .qss-item:hover svg path ' => 'fill: {{VALUE}};',
                
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'icon_box_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .qss-item:hover .qss-icon i',
               
            ]
        );
     
        $this->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'icon_border_hv_background',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .qss-icon i',
            ]
        );

        $this->add_control(
            'icon_hover_heading1',
            [
                'label' => esc_html__( 'Hover', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
 
       

        $this->add_control(
            'icon_hover_border_heading1',
            [
                'label' => esc_html__( 'Icon Border', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

      
        $this->add_responsive_control(
            'icon_box_n_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .qss-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            '_icon_npx_m_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .qss-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section('appscred_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .qss-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .qss-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );   
            
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => '_item_content_section_border',
                    'label' => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .qss-item',
                ]
            );

            $this->add_responsive_control(
                '_item_content_section_border_radious',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                    
                        'selectors' => [
                            '{{WRAPPER}} .qss-item' => 'border-radius: {{VALUE}}px;',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => '_item_section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .qss-item',
                    ]
            );
            $this->add_control(
                'hover_itembakcground__heading1',
                [
                    'label' => esc_html__( 'hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'hover_item__hvv_section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .qss-item:hover',
                    ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'hover_item_content_section_border',
                    'label' => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .qss-item:hover',
                ]
            );
            //
          
            
          
        $this->end_controls_section();

        $this->start_controls_section('appscred_style_slider_nav',
        [
           'label' => esc_html__( 'Navigation', 'insut-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
        
        $this->add_control(
           'nav_color',
           [
              'label'     => esc_html__('Color', 'insut-essential'),
              'type'      => Controls_Manager::COLOR,
              'selectors' => [
                 '{{WRAPPER}} .owl-nav i' => 'color: {{VALUE}};',
               
              ],
            
           ]
        );

        $this->add_control(
         'nav_hvcolor',
         [
            'label'     => esc_html__('Hover color', 'insut-essential'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
               '{{WRAPPER}} .owl-nav:hover i' => 'color: {{VALUE}};',
             
            ],
           
         ]
      );

      $this->add_control(
			'nav_background_heading',
			[
				'label'     => esc_html__( 'Nav background', 'insut-essential' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
      );
      
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
            [
               'name'     => 'nav_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient' ],
               'selector' => '{{WRAPPER}} .quote-serive-slider.owl-carousel .owl-nav button ',
            ]
         );

        
        
         
         $this->add_control(
            'nav_hvbackground_heading',
            [
               'label'     => esc_html__( 'Nav Hover background', 'insut-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'after',
               
            ]
         );   
         $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
            [
               'name'      => 'nav_hv_background',
               'label'     => esc_html__( 'Background', 'insut-essential' ),
               'types'     => [ 'classic', 'gradient' ],
               'selector'  => '{{WRAPPER}} .quote-serive-slider.owl-carousel .owl-nav button:hover',
              
            ]
	   	);
 
        
         $this->add_control(
            'nav_width',
            [
               'label'      => esc_html__( 'Width', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 5,
                     'max'  => 200,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .quote-serive-slider.owl-carousel .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );
   

         $this->add_responsive_control(
            'nav_border_radius',
            [
               'label'      => esc_html__( 'Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .quote-serive-slider.owl-carousel .owl-nav button'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
                 
                  
               ],
            ]
           );
         
        $this->end_controls_section();
        $this->start_controls_section('appscred_main_section',
                [
                'label' => esc_html__( 'Section', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'insut-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'insut-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'insut-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );

                    $this->add_control(
                        'section_left_shape_heading1',
                        [
                            'label' => esc_html__( 'Left Shape', 'insut-essential' ),
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                            [
                                'name'     => 'left_shape_border_background',
                                'label'    => esc_html__( 'Background', 'insut-essential' ),
                                'types'    => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .quote-service:before',
                            ]
                    );

                    $this->add_control(
                        'section_right_shape_heading1',
                        [
                            'label' => esc_html__( 'Left Shape', 'insut-essential' ),
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                            [
                                'name'     => 'right_shape_border_background',
                                'label'    => esc_html__( 'Background', 'insut-essential' ),
                                'types'    => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .quote-service:after',
                            ]
                    );

        $this->end_controls_section();
    } //Register control end
    public function elementor_template() {
        $templates = \Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
        $types     = array();
        if ( empty( $templates ) ) {
            $template_lists = [ '0' => __( 'Do not Saved Templates.', 'insut-essential' ) ];
        } else {
            $template_lists = [ '0' => __( 'Select Template', 'insut-essential' ) ];
            foreach ( $templates as $template ) {
                $template_lists[ $template['template_id'] ] = $template['title'] . ' (' . $template['type'] . ')';
            }
        }
        return $template_lists;
    }
    protected function render( ) { 

		$settings        = $this->get_settings();
		$list            = $settings['list'];
        $slide_controls = insut_widgets_owl_slider_controls_setttings($settings);
        $class_owl       = $settings['slider_enable'] == 'yes'? 'owl-carousel':'';

    ?>
       
       <?php if($settings['style'] == 'style1'): ?>
            <div class="quote-service main-section">
                <?php if($settings['template_id'] !=''): ?>
                    <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $settings['template_id'] ); ?>
                <?php endif; ?>
                <div class="quote-serive-slider <?php echo esc_attr($class_owl); ?>" data-controls='<?php echo json_encode($slide_controls); ?>'>
                    <?php foreach($list as $item): ?>
                        <?php 
                             if($item['list_service']){

                            $service_post = get_post($item['list_service']); 
                       ?>
                        <a href="<?php echo esc_url(get_the_permalink($item['list_service'])); ?>" class="qss-item">
                            <div class="qss-icon">
                                <?php if( $item['list_icon']['value'] == '' ): ?>
                                <i class="icofont-home"></i>
                                <?php else: ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif; ?>
                            </div>
                            <h5 class="title">
                                <?php if($item['list_title'] != ''): ?>
                                    <?php echo  esc_html( $item['list_title'] ); ?> 
                                <?php else: ?>
                                    <?php echo  esc_html( get_the_title($item['list_service']) ); ?> 
                                <?php endif; ?>
                            </h5>
                        </a>
                    <?php }  endforeach; ?>
                  
                </div>
            </div>
        <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }

    protected function get_service_list(){
        $_list = [];
        $args = array(
              'numberposts'      => -1,
              'orderby'          => 'post_date',
              'order'            => 'DESC',
              'post_type'        => 'quomodo-service',
              'post_status'      => 'publish',
              'suppress_filters' => false
        );
  
        $services = get_posts($args);
   
        if($services):
         // Loop the posts
           foreach ($services as $feature):
             $_list[$feature->ID] = $feature->post_title; 
           endforeach;
        endif;
  
        return $_list;  
    }
}