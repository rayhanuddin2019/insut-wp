<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;


class Button extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-button';
    }

    public function get_title() {
        return esc_html__( 'Insut Button', 'insut-essential' );
    }

    public function get_icon() { 
        return 'eicon-dual-button';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {

       
        $this->start_controls_section(
            'section_button_tab',
            [
                'label' => esc_html__('Button settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label' => esc_html__( 'Style', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1'  => esc_html__( 'Style 1', 'insut-essential' ),
                        'style2' => esc_html__( 'Style 2', 'insut-essential' ),
                        'style3' => esc_html__( 'Style 3', 'insut-essential' ),
                        'style4' => esc_html__( 'Style 4', 'insut-essential' ),
                    ],
                ]
            );

            $this->add_control(
                'button_text', [
                    'label'       => esc_html__( 'Button text', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'button_url', [
                    'label'       => esc_html__( 'Button Url', 'insut-essential' ),
                    'type'        => Controls_Manager::URL,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    
                ]
            );

            $this->add_responsive_control(
                'icon_padding2',
                [
                    'label'      => esc_html__( 'Icon Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .insut-btn i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );
          
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_button_style2', [
				'label' => esc_html__( 'Button', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'fea_button_color2', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .insut-btn' => 'color: {{VALUE}};',
                      
                        ],
                    ]
                );

                $this->add_control(
                    'fea_button_hv_color2', [

                        'label'     => esc_html__( 'Hover Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .ab-ht-content .insut-btn:hover' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .insut-btn:hover' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'button_content_typho2',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin2',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .insut-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'button_background_heading2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );
                $this->add_control(
                    'button_background_hv_heading2',
                    [
                        'label' => esc_html__( 'Background hover color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_hv_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .ab-ht-content .insut-btn:hover,{{WRAPPER}} .insut-btn:hover',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .insut-btn' => 'border-radius: {{VALUE}}px;',
                              
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button2_section_border',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

                $this->add_responsive_control(
                    'inputs_submit_width',
                    [
                        'label'      => esc_html__( 'Width', 'insut-essential' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0,
                                'max'  => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn' => 'width:{{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
                $this->add_responsive_control(
                    'input_ssubmit_height',
                    [
                        'label'      => esc_html__( 'Height', 'insut-essential' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'max' => 150,
                            ],
                        ],
                      
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow:: get_type(),
                    [
                        'name'     => 'inpust_submit_box_shadow',
                        'label'    => esc_html__( 'Box Shadow', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

               

        $this->end_controls_section();

        $this->start_controls_section('appscred_mainss_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'style' => ['style3'] ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
                'name'     => 'button_input_section_h_background2',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .service-section-2:before',
            ]
        );

            $this->add_responsive_control(
            'section_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );

            $this->add_responsive_control(
            'section_box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );
          
          $this->end_controls_section();
       
       
        
        

    } //Register control end

    protected function render( ) { 

        $settings    = $this->get_settings();
        $button_url  = $settings['button_url'];
        $button_text = $settings['button_text'];
     
    ?>
        <?php if($settings['style'] == 'style1'): ?>   
            <?php  if( $settings['button_text'] !='' ): ?> 
                <div class="ab-ht-content" >
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="insut-btn">
                
                            <?php if( $settings['icon']['value'] == '' ): ?>
                                <i class="icofont-home"></i>
                            <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                            <?php echo esc_html( $settings['button_text'] ); ?>

                    </a> 
                </div>    
            <?php endif; ?>     
           
       <?php endif; ?>

       <?php if($settings['style'] == 'style2'): ?>   
            <?php  if( $settings['button_text'] !='' ): ?> 
                <div class="why-choose-thumb" >
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="insut-btn">
                
                            <?php if( $settings['icon']['value'] == '' ): ?>
                                <i class="icofont-ui-user"></i>
                            <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                            <?php echo esc_html( $settings['button_text'] ); ?>

                    </a> 
                </div>    
            <?php endif; ?>     
           
       <?php endif; ?>
       <?php if($settings['style'] == 'style3'): ?>   
            <?php  if( $settings['button_text'] !='' ): ?> 
                <div class="service-section-2 main-section" >
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="insut-btn">
                
                            <?php if( $settings['icon']['value'] == '' ): ?>
                                <i class="icofont-ui-user"></i>
                            <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                            <?php echo esc_html( $settings['button_text'] ); ?>

                    </a> 
                </div>    
            <?php endif; ?>     
           
       <?php endif; ?>

       <?php if($settings['style'] == 'style4'): ?>   
            <?php  if( $settings['button_text'] !='' ): ?> 
                
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="insut-btn">
                
                            <?php if( $settings['icon']['value'] == '' ): ?>
                                <i class="icofont-ui-user"></i>
                            <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                            <?php echo esc_html( $settings['button_text'] ); ?>

                    </a> 
                 
            <?php endif; ?>     
           
       <?php endif; ?>

     
           
    <?php  

    }
    
    protected function _content_template() { }
}