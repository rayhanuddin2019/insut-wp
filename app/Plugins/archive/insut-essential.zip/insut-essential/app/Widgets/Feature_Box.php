<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Feature_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-feature-box';
    }

    public function get_title() {
        return esc_html__( 'Feature Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'insut-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [

               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                    'imagelarge' => INSUT_IMG . '/admin/feature/style1.png',
                    'imagesmall' => INSUT_IMG . '/admin/feature/style1.png',
                    'width'      => '50%',
               ], 
               
              
               'style2' => [
                'title'      => esc_html__( 'Style 2', 'insut-essential' ),
                'imagelarge' => INSUT_IMG . '/admin/feature/style2.png',
                'imagesmall' => INSUT_IMG . '/admin/feature/style2.png',
                'width'      => '49%',
               ], 
           
         
         
           ],

         ]
       ); 
       $this->end_controls_section();
      


        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Feature settings', 'insut-essential'),
            ]
        );
       
       

		$this->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
     
		$this->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( 'List Content' , 'insut-essential' ),
                'show_label' => false,
                'condition' => [ 'block_style' => ['style1'] ],
			]
		);

        $this->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );
   
	
     
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .about-us-area' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .f-box-title' => 'text-align: {{VALUE}};',
                    

				],
			]
        );//Responsive control end

        $this->end_controls_section();
      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Title color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                 
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .title,{{WRAPPER}} .f-box-title .title',
            ]
        );
        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .feature-item .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .feature-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'section_desc_style', [
				'label' => esc_html__( 'Description', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style1'] ],
			]
        );


        $this->add_control(
			'desc_color', [

				'label'     => esc_html__( 'Desc color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .feature-item .text' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .text' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .text,{{WRAPPER}} .features-item .text',
            ]
        );

        $this->add_responsive_control(
            'desc_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .feature-item .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'desc_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .feature-item .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        
        
        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control('box_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  
                    '{{WRAPPER}} .feature-item' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .ab-icon-box' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .f-box-title' => 'background: {{VALUE}};',
      
                            
                    ],
                ]
            );

            $this->add_control(
                'box_hv_background_heading1',
                [
                    'label' => esc_html__( 'Background Hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    
                ]
            );
            $this->add_control('box_hv_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
               
                'selectors' => [
                      '{{WRAPPER}} .feature-item::before' => 'background: {{VALUE}};',
                      '{{WRAPPER}} .ab-icon-box:hover' => 'background: {{VALUE}};',
                      '{{WRAPPER}} .f-box-title:hover' => 'background: {{VALUE}};',
                            
                    ],
                ]
               
            );
            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'     => 'box_border',
                    'label'    => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .ab-icon-box,{{WRAPPER}} .f-box-title',
                ]
            );


            $this->add_responsive_control(
                '_box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        
                        '{{WRAPPER}} .ab-icon-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .f-box-title' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        
                        '{{WRAPPER}} .feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .ab-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .f-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                    ],
                ]
            );

            $this->add_responsive_control(
                'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .f-box-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                      
                        ],
                    ]
            );


            $this->add_control(
                'left_shape_bgcolor', [
    
                    'label'     => esc_html__( 'Left Shape color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'condition' => [ 'block_style' => ['style1'] ],
                    'selectors' => [
                      '{{WRAPPER}} .ab-icon-box:before' => 'background: {{VALUE}};',
                     
                    ],
                ]
            );

        $this->end_controls_section();
       
     $this->start_controls_section('appscred_box_media_section',
        [
        'label' => esc_html__( 'Media / Icon', 'insut-essential' ),
        'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'icon_color_background', [

                'label'     => esc_html__( 'Icon background box color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
               
                'selectors' => [
                '{{WRAPPER}} .feature-item .icon' => 'background: {{VALUE}};',
                '{{WRAPPER}} .ab-icon-box i' => 'background: {{VALUE}};',
                '{{WRAPPER}} .f-box-title i' => 'background: {{VALUE}};',
                
                ],
            ]
        );
        $this->add_control(
            'box_icon_color', [

                'label'     => esc_html__( 'Box Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
             
                   '{{WRAPPER}} .ab-icon-box svg path' => 'fill: {{VALUE}};',
                   '{{WRAPPER}} .ab-icon-box i' => 'color: {{VALUE}};',
                   '{{WRAPPER}} .f-box-title i' => 'color: {{VALUE}};',
                   '{{WRAPPER}} .f-box-title svg path' => 'fill: {{VALUE}};',
                   
             
                ],
            ]
        );


        $this->add_responsive_control(
			'box_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .feature-item .icon svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ab-icon-box i' => 'width: {{SIZE}}{{UNIT}};',
			
				],
			]
        );

        $this->add_responsive_control(
            'icon__box_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ab-icon-box i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
			'box_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .ab-icon-box i' => 'height: {{SIZE}}{{UNIT}};',
				
				],
			]
        );

        $this->add_responsive_control(
            'media_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .feature-item .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .ab-icon-box i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                        
                    ],
                ]
            );

            $this->add_responsive_control(
            'media_box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .feature-item .icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .ab-icon-box i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                    ],
                ]
            );
    $this->end_controls_section();

    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
	
       
    ?>
   
     <?php if( $settings['block_style'] == 'style1' ): ?>
        
               <!-- About Content Start -->
               <div class="about-us-area">
                          
                    <div class="ab-icon-box">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <h4 class="title"><?php echo esc_html($settings['list_title']); ?></h4>
                        <p class="text">
                            <?php echo esc_html($settings['list_content']); ?>
                        </p>
                    </div>

                </div>
                <!-- About Content End -->
       
      <?php endif; ?>
      <?php if($settings['block_style'] == 'style2'): ?>
            <div class="f-box-title">
                <h4 class="title"><?php echo esc_html($settings['list_title']); ?></h4>
                <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </div>
      <?php endif; ?>
   
     
  
  

    <?php  

    }
    
    protected function _content_template() { }
}