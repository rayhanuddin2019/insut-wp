<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;



if ( ! defined( 'ABSPATH' ) ) exit;


class Brand extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-brand';
    }

    public function get_title() {
        return esc_html__( 'Brand Sponsor', 'insut-essential' );
    }
    public function get_keywords() {
		return [ 'image', 'brand', 'sponsor', 'insut' ];
	}
    public function get_icon() { 
        return 'eicon-gallery-grid';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
   
    protected function _register_controls() {

         $this->start_controls_section(
               'section_layout_tab',
               [
                  'label' => esc_html__('Layout', 'insut-essential'),
               ]
         );
         
         $this->add_control(
            'layout',
            [
               'label'   => esc_html__( 'Layout Style', 'insut-essential' ),
               'type'    => \Elementor\Controls_Manager::SELECT,
               'default' => 'clinet-logo',
               'options' => [
                     'clinet-logo' => esc_html__( ' Style 1', 'insut-essential' ),
                     'clinet-logo-two' => esc_html__( ' Style 2', 'insut-essential' ),
                     
              
           
               ],
            ]
         );

      $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Brand Sponsor Settings', 'insut-essential'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
           'list_title', [
              'label' => esc_html__( 'Title', 'insut-essential' ),
              'type' => \Elementor\Controls_Manager::TEXT,
              'default' => esc_html__( 'List Title' , 'insut-essential' ),
              'label_block' => true,
           ]
        );
  
        $repeater->add_control(
            'list_url', [
               'label' => esc_html__( 'Url', 'insut-essential' ),
               'type' => \Elementor\Controls_Manager::TEXT,
               'default' => esc_html__( 'List Url' , 'insut-essential' ),
               'label_block' => true,
            ]
         );

         $repeater->add_control(
            'list_image',
            [
               'label' => esc_html__( 'Choose Image', 'insut-essential' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' => \Elementor\Utils::get_placeholder_image_src(),
               ],
            ]
         );

         $repeater->add_control(
            'list_active',
            [
               'label' => esc_html__( 'Active', 'insut-essential' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'label_on' => esc_html__( 'Active', 'insut-essential' ),
               'label_off' => esc_html__( 'Inactive', 'insut-essential' ),
               'return_value' => 'yes',
               'default' => 'yes',
            ]
         );

        $this->add_control(
           'list',
           [
              'label' => esc_html__( 'Sponsor List', 'insut-essential' ),
              'type' => \Elementor\Controls_Manager::REPEATER,
              'fields' => $repeater->get_controls(),
              'title_field' => '{{{ list_title }}}',
           ]
        );
  
  

        $this->end_controls_section();
       //Image Style Section
		$this->start_controls_section(
			'section_image_style', [
				'label' => esc_html__( 'Image', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

   
               $this->add_responsive_control(
                     'box_image_height',
                     [
                        'label'      => esc_html__( 'Image height', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ,'%' ],
                        'range'      => [
                           'px' => [
                              'min'  => 0,
                              'max'  => 800,
                              'step' => 1,
                           ],
                        
                        ],
                     
                        'selectors' => [
                           '{{WRAPPER}} .brand-item img' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                     ]
                  );


                  $this->add_responsive_control(
                     'image_brand_opacity',
                        [
                           'label' => esc_html__( ' Opacity', 'insut-essential' ),
                           'type'  => \Elementor\Controls_Manager::SLIDER,
                           'range'      => [
                              'px' => [
                                 'min'  => 0,
                                 'max'  => 1,
                                 'step' => 0.1,
                              ],
                           
                           ],
                        
                           'selectors' => [
                                 '{{WRAPPER}} .brand-item img' => 'opacity: {{SIZE}};',
                           ],
                         
                     ]
                  ); 
   
               $this->add_control(
                     'image_hover_heading1',
                     [
                        'label' => esc_html__( 'Hover', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                     ]
               );
               
               
               
               
               $this->add_responsive_control(
                  'image_hv_opacity',
                     [
                        'label' => esc_html__( 'Hover Opacity', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::SLIDER,
                        'range'      => [
                           'px' => [
                              'min'  => 0,
                              'max'  => 1,
                              'step' => 0.1,
                           ],
                        
                        ],
                     
                        'selectors' => [
                              '{{WRAPPER}} .brand-area .brand-item img:hover' => 'opacity: {{SIZE}};',
                     ],
                  ]
               ); 

               $this->add_responsive_control(
                  'image_filter_opacity',
                     [
                        'label' => esc_html__( 'Hover Filter', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::SLIDER,
                        'range'      => [
                           '%' => [
                              'min'  => 0,
                              'max'  => 100,
                              'step' => 1,
                           ],
                        
                        ],
                     
                        'selectors' => [
                              '{{WRAPPER}} .brand-area .brand-item img:hover' => 'filter: grayscale({{SIZE}}%);',
                     ],
                  ]
               ); 

               $this->add_group_control(
						\Elementor\Group_Control_Css_Filter::get_type(),
						[
							'name'      => 'icon_image_filters',
							'selector'  => '{{WRAPPER}} img',
							
						]
					);
               
         $this->end_controls_section();
         $this->start_controls_section(
            'section_items_style', [
               'label' => esc_html__( 'Items', 'insut-essential' ),
               'tab'   => Controls_Manager::TAB_STYLE,
                   
            ]
         );

            
           
                  $this->add_responsive_control(
                        'section_thumb_image_radius',
                           [
                              'label' => esc_html__( 'Border radius', 'insut-essential' ),
                              'type'  => \Elementor\Controls_Manager::NUMBER,
                              'min'   => 0,
                              'max'   => 800,
                              'step'  => 1,
                           
                              'selectors' => [
                                    '{{WRAPPER}} .brand-item' => 'border-radius: {{VALUE}}px;',
                           ],
                        ]
                  ); 

                  $this->add_responsive_control(
                     'box_item_image_height',
                     [
                        'label'      => esc_html__( ' height', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ,'%' ],
                        'range'      => [
                           'px' => [
                              'min'  => 0,
                              'max'  => 800,
                              'step' => 1,
                           ],
                        
                        ],
                     
                        'selectors' => [
                           '{{WRAPPER}} .brand-item' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                     ]
                  );

                  $this->add_responsive_control(
                  'box_item_image_width',
                  [
                     'label'      => esc_html__( 'Width', 'insut-essential' ),
                     'type'       => Controls_Manager::SLIDER,
                     'size_units' => [ 'px','%' ],
                     'range'      => [
                        'px' => [
                           'min'  => 0,
                           'max'  => 800,
                           'step' => 1,
                        ],
                     
                     ],
                  
                     'selectors' => [
                        '{{WRAPPER}} .brand-item' => 'width: {{SIZE}}{{UNIT}};',
                     ],
                  ]
               );
            $this->add_control(
                  'section_background_heading1_normal',
                  [
                     'label' => esc_html__( 'Item Background ', 'insut-essential' ),
                     'type' => \Elementor\Controls_Manager::HEADING,
                     'separator' => 'before',
                  ]
            );

            $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
               [
                  'name'      => 'item_hv_image_background',
                  'label'     => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector'  => '{{WRAPPER}} .main-section .brand-item,{{WRAPPER}} .brand-item',
               
               ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Border::get_type(),
               [
                  'name' => 'item__image_border',
                  'label' => esc_html__( 'Border', 'insut-essential' ),
                  'selector' => '{{WRAPPER}} a',
               ]
            );

            $this->add_control(
                  'item_background_heading1_hover',
                  [
                     'label' => esc_html__( 'Item Hover Background', 'insut-essential' ),
                     'type' => \Elementor\Controls_Manager::HEADING,
                     'separator' => 'before',
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'      => 'item_hv_image_background_hover',
                  'label'     => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector'  => '{{WRAPPER}} .main-section .brand-item:hover',
               
               ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Border::get_type(),
               [
                  'name' => 'item_hv_image_border',
                  'label' => esc_html__( 'Border', 'insut-essential' ),
                  'selector' => '{{WRAPPER}} a:hover',
               ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Box_Shadow::get_type(),
               [
                  'name' => 'item_hv_image_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                  'selector' => '{{WRAPPER}}  a:hover',
               ]
            );

         $this->end_controls_section();
         $this->start_controls_section(
            'section_active_item_style', [
               'label' => esc_html__( 'Active Item', 'insut-essential' ),
               'tab'   => Controls_Manager::TAB_STYLE,
                     
            ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Box_Shadow::get_type(),
               [
                  'name' => 'item_active_item_image_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                  'selector' => '{{WRAPPER}}  .active',
               ]
            );
            $this->add_group_control(
               \Elementor\Group_Control_Border::get_type(),
               [
                  'name' => 'item_active_item_image_border',
                  'label' => esc_html__( 'Border', 'insut-essential' ),
                  'selector' => '{{WRAPPER}} .active',
               ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'      => 'item_active_item_background_hover',
                  'label'     => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector'  => '{{WRAPPER}} .active',
               
               ]
            );
            
            $this->add_group_control(
               \Elementor\Group_Control_Css_Filter::get_type(),
               [
                  'name'      => 'active_item_image_filters',
                  'selector'  => '{{WRAPPER}} .active img',
                 
               ]
            );
         $this->end_controls_section();

         $this->start_controls_section(
         'section_box_style', [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
                  
         ]
         ); 

        $this->add_control(
               'section_background_heading1',
               [
                  'label' => esc_html__( 'Section Background', 'insut-essential' ),
                  'type' => \Elementor\Controls_Manager::HEADING,
                  'separator' => 'before',
               ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name'      => 'post_image_background',
               'label'     => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector'  => '{{WRAPPER}} .main-section',
              
            ]
         );

         $this->add_responsive_control(
            'single_box_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );
         $this->add_responsive_control(
            'single_box_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
            );
     
    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings_for_display();

	   $list = $settings['list'];
    
	  
    ?>
      
       
           <!-- Client Logo Start -->
        <section class="<?php echo esc_attr($settings['layout']); ?> clearfix main-section">
       
            <?php foreach( $list as $sponsor ): ?>
               <?php if($sponsor['list_image']['url'] !=''): ?>
                     <a class="<?php echo esc_attr($sponsor['list_active']=='yes'?'active':''); ?> brand-item" href="<?php echo esc_url($sponsor['list_url']); ?> "><img src=" <?php echo esc_url($sponsor['list_image']['url']); ?> " alt="<?php echo esc_attr($sponsor['list_title']); ?>"></a>
               <?php endif; ?>
            <?php endforeach; ?>
           
        </section>
        <!-- Client Logo End -->


    <?php  

    }
    
    protected function _content_template() { }
}