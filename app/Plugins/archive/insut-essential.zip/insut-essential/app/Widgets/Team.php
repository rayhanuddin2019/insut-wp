<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Team extends Widget_Base {

    public $base;

    public function get_name() {
        return 'insut-team';
    }

    public function get_title() {
        return esc_html__( 'Insut Team', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-users";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Insut Team', 'insut-essential'),
            ]
        );

        $this->add_control(

            'style', [
                'label'   => esc_html__('Choose Style', 'insut-essential'),
                'type'    => Custom_Controls_Manager::RADIOIMAGE,
                'default' => 'style1',
                'options' => [
                        'style1' => [
                                'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                                'imagelarge' => INSUT_IMG . '/admin/team/style2.png',
                                'imagesmall' => INSUT_IMG . '/admin/team/style2.png',
                                'width'      => '50%',
                        ],
                        'style2' => [
                            'title'      => esc_html__( 'Style 2', 'insut-essential' ),
                            'imagelarge' => INSUT_IMG . '/admin/team/style1.png',
                            'imagesmall' => INSUT_IMG . '/admin/team/style1.png',
                            'width'      => '49%',
                    ],
                ],

            ]
        ); 

        $this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'insut-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Name here', 'insut-essential' ),
				'default'     => esc_html__( 'Adam', 'insut-essential' ),
               
				
			]
        );
        $this->add_control(
			'team_link', [
				'label'       => esc_html__( 'Member Url', 'insut-essential' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
			
               
				
			]
        );
        $this->add_control(
			'designation', [
				'label'       => esc_html__( 'Designation', 'insut-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Designation here', 'insut-essential' ),
				'default'     => esc_html__( 'CEO & Founder', 'insut-essential' ),
               
				
			]
        );

        $social = new \Elementor\Repeater();
      
      
        $social->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);

        $social->add_control(
			'list_link', [
				'label'       => esc_html__( 'Url', 'insut-essential' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				
			]
        );
        
		$social->add_control(
			'list_title', [
				'label' => esc_html__( 'Name', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Social Name' , 'insut-essential' ),
				'label_block' => true,
			]
        );

        $social->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'icon_back_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .member-social {{CURRENT_ITEM}} a, {{WRAPPER}} .member-social-link {{CURRENT_ITEM}} a',
                ]
            );

        $social->add_control(
            'icon_box_color', [

                'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .member-social {{CURRENT_ITEM}} i' => 'color: {{VALUE}};',
                '{{WRAPPER}} .member-social-link {{CURRENT_ITEM}} i' => 'color: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}} svg path' => 'fill: {{VALUE}};',
                
                ],
            ]
        );

        $social->add_responsive_control(
            'item_position_top',
            [
               'label'      => esc_html__( 'Top', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -500,
                     'max'  => 500,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}}  {{CURRENT_ITEM}} a' => 'top: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );

         $social->add_responsive_control(
            'item_position_bottom',
            [
               'label'      => esc_html__( 'Bottom', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -500,
                     'max'  => 500,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} {{CURRENT_ITEM}} a' => 'bottom: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );

         $social->add_responsive_control(
            'item_position_left',
            [
               'label'      => esc_html__( 'Left', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -500,
                     'max'  => 500,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} {{CURRENT_ITEM}} a' => 'left: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );

         $social->add_responsive_control(
            'item_position_right',
            [
               'label'      => esc_html__( 'Right', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -500,
                     'max'  => 500,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} {{CURRENT_ITEM}} a' => 'right: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );
   
		$this->add_control(
			'social_list',
			[
				'label' => esc_html__( 'Social List', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $social->get_controls(),
				'default' => [

					[
						'list_title' => esc_html__( 'Facebook', 'insut-essential' ),
					],
				
				],
				'title_field' => '{{{ list_title }}}',
			]
		);
   
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .single-team' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .single-member' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .member-name' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .member-name',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
           
           //  designation
            $this->add_control(
                'designation_color', [

                    'label'     => esc_html__( 'Designation color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .member-designation' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'designation_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .member-designation',
                ]
            );

            $this->add_responsive_control(
                'designation_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .member-designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'designation_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .member-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );    

        $this->end_controls_section();
        $this->start_controls_section(
			'section_overlay_style', [
				'label' => esc_html__( 'Overlay', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'style' => ['style2'] ],
			]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'overlay_inner_section_background',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .member-datils',
               
            ]
        );

       
           
        $this->add_control(
            'image_overlay_opecity',
            [
               'label'      => esc_html__( 'Opacity', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 1,
                     'step' => .1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .member-datils' => 'opacity: {{SIZE}};',
               ],
              
              
            ]
         );
         $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'style2_content_section_border',
                'label' => esc_html__( 'Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .member-datils',
            ]
        );

        $this->add_responsive_control(
            'item_details_image_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .member-datils' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
           
                
                'separator' => 'before',
            ]
        );
    
        $this->add_responsive_control(
            'details_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .member-datils' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        ); 

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_icon_style', [
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

                $this->add_control(
                    'team_social_icon_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .member-social li i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .member-social-link li i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .member-social li svg path' => 'fill: {{VALUE}};',
                        '{{WRAPPER}} .member-social-link li svg path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_control(
                    'team_social_hv_icon_color', [

                        'label'     => esc_html__( 'Hover Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .member-social li:hover i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .member-social-link li:hover i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .member-social li:hover svg path' => 'fill: {{VALUE}};',
                        '{{WRAPPER}} .member-social-link li:hover svg path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'icon_front_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .member-social li a,{{WRAPPER}} .member-social-link li a',
                    ]
                );

                $this->add_control(
                    'section_icon_hover_heading1',
                    [
                        'label' => esc_html__( 'Hover', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'icon_hover_border_background',
                            'label'    => esc_html__( 'Background', 'insut-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .member-social li a:after, {{WRAPPER}} .member-social-link li a:after',
                        ]
                    );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'soclail_icon_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} li svg,{{WRAPPER}} .member-social li i, {{WRAPPER}} .member-social-link li i',
                    ]
                );
            
                $this->add_responsive_control(
                    'team_list_image_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'condition' => [ 'style' => ['style1'] ], 
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                            
                        ],
                   
                        
                        'separator' => 'before',
                    ]
                );
            
                $this->add_responsive_control(
                    'soclial_icon_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-social li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .member-social-link li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'social_cion_borderion_border',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} li a',
                    ]
                );

              
                    $this->add_control(
                        'soclial_position_left',
                        [
                        'label'      => esc_html__( 'Left', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'condition' => [ 'style' => ['style2'] ], 
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -500,
                                'max'  => 500,
                                'step' => 1,
                            ],
                            
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .member-social-link' => 'left: {{SIZE}}{{UNIT}};',
                            
                            
                        ],
                        ]
                    );

                    $this->add_control(
                        'soclial_position_botpm',
                        [
                        'label'      => esc_html__( 'Bottom', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'condition' => [ 'style' => ['style2'] ], 
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -500,
                                'max'  => 500,
                                'step' => 1,
                            ],
                            
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .member-social-link' => 'bottom: {{SIZE}}{{UNIT}};',
                            
                            
                        ],
                        ]
                    );
        $this->end_controls_section();
       
    

        $this->start_controls_section('appscred_box__main_section',
                [
                'label' => esc_html__( 'Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
       
         
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .single-team' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .single-member' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .single-team' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .single-member' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'service_list_section_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .single-team,{{WRAPPER}} .single-member',
                   
                ]
            );

            $this->add_control(
                '_section_box_radius',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                       
                        'selectors' => [
                            '{{WRAPPER}} .single-team' => 'border-radius: {{VALUE}}px;',
                            '{{WRAPPER}} .single-member' => 'border-radius: {{VALUE}}px;',
                    ],
                ]
            ); 

            $this->add_control(
                'section_left_shape_heading1',
                [
                    'label' => esc_html__( 'Left Shape', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'style' => ['style1'] ], 
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'left_shape_border_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .single-team:before',
                        'condition' => [ 'style' => ['style1'] ], 
                    ]
            );

            $this->add_control(
                'section_right_shape_heading1',
                [
                    'label' => esc_html__( 'Right Shape', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'style' => ['style1'] ], 
                ]
            );

            
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'right_shape_border_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .single-team:after',
                        'condition' => [ 'style' => ['style1'] ], 
                    ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'main_section_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .single-team',
                    'selector' => '{{WRAPPER}} .single-member',
                ]
            );

         

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'main_section_hv_box_shadow',
                    'label' => esc_html__( 'Box Shadow hover', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .single-team:hover,{{WRAPPER}} .single-member:hover',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'section_item_content_section_border',
                    'label' => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .single-team,{{WRAPPER}} .single-member',
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings    = $this->get_settings();
		$social_list = $settings['social_list'];
		$button_url  = $settings['team_link'];
        
       
    ?>
         <?php if($settings['style'] == 'style1'): ?>
                     <!-- Single Team Start -->
                     <div class="single-team">
                        <div class="team-thumb">
                            <?php if($settings['image']['url'] !=''): ?>
                               <img class="member-img" src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                            <?php endif; ?>
                            <ul class="member-social">
                                
                                  <?php foreach($social_list as $item): ?>
                                    <li class="elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?> ">
                                        <?php 
                                           $social_url = $item['list_link'];
                                        ?>
                                        <a target="<?php echo esc_attr( $social_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($social_url['url']) ?>" class="social-link">
                                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </a>
                                    </li>
                                 <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="team-details">
                            <h4 class="member-name"><a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="team-link">
                            <?php echo esc_html($settings['name'] ); ?></a>
                            </h4>
                            <p class="member-designation"><?php echo esc_html($settings['designation'] ); ?></p>
                        </div>
                    </div>
                    <!-- Single Team End -->
         <?php endif; ?>
         <?php if($settings['style'] == 'style2'): ?>
                        <div class="single-member">
                            <?php if($settings['image']['url'] !=''): ?>
                                <img class="member-img" src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                            <?php endif; ?>
                            <div class="member-datils">
                                <h5 class="member-name"> <?php echo esc_html($settings['name'] ); ?> </h5>
                                <p class="meber-designation member-designation"><?php echo esc_html($settings['designation'] ); ?></p>
                                <ul class="member-social-link">
                                   
                                    <?php foreach($social_list as $item): ?>
                                        <li class="elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?> ">
                                            <?php 
                                            $social_url = $item['list_link'];
                                            ?>
                                            <a target="<?php echo esc_attr( $social_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($social_url['url']) ?>" class="social-link">
                                                <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                    
                                </ul>
                            </div>
                        </div>
         <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}