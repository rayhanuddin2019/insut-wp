<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Case_Study extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-case-study';
    }

    public function get_title() {
        return esc_html__( 'Insut Case Study', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fa fa-telegram';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
    public function layout(){
        return[
            
            'style1'   => esc_html__( 'Standard', 'insut-essential' ),
            'style2' => esc_html__( 'Creative', 'insut-essential' ),
        
    
        ];
    }
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
                
                $this->add_control(
                    'custom_case',
                    [
                        'label'     => esc_html__('Custom Case Study', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => '',
                        
                    ]
                ); 

                $this->add_control(
                    'case',
                    [
                        'label' => esc_html__( 'Case items', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT2,
                        'multiple' => true,
                        'options' => $this->get_case_list(),
                        'condition' => [ 
                            'custom_case' => ['']
                        ],
                        'show_label' => true,
                        'label_block' => true,
                    ]
                );

                $this->add_control(
                    'cat',
                    [
                        'label' => esc_html__( 'Case Category', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT2,
                        'multiple' => true,
                        'options' => $this->get_category(),
                        'show_label' => true,
                        'label_block' => true,
                    ]
                );

                $this->add_control(
                    'custom_case_ids', [
                        'label'       => esc_html__( 'Custom Case ids', 'insut-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                        'default'     => esc_html__( '1, 2' , 'insut-essential' ),
                        'placeholder' => esc_html__( '1, 2' , 'insut-essential' ),
                        'description' => esc_html__( 'post id seperate with comma' , 'insut-essential' ),
                        'show_label'  => true,
                        'condition'   => [ 
                            'custom_case' => ['yes']
                        ],
                    ]
                );

                $this->add_control(
                'post_count',
                    [
                        'label'   => esc_html__( 'Post count', 'insut-essential' ),
                        'type'    => Controls_Manager::NUMBER,
                        'default' => '6',
                    ]
                );
                $this->add_control(
                    'post_title_crop',
                    [
                    'label'   => esc_html__( 'Title limit', 'insut-essential' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => '20',
                    
                    ]
                ); 
             
        
                $this->add_control(
                    'post_sort',
                    [
                        'label' => esc_html__( 'Sort', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'DESC',
                        'options' => [
                            'ASC'  => esc_html__( 'ASC', 'insut-essential' ),
                            'DESC' => esc_html__( 'DESC', 'insut-essential' ),
                        ],
                    ]
                );

                $this->add_control(
                    'show_more_active',
                    [
                        'label'     => esc_html__('Show show more button', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                        
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Image_Size::get_type(),
                    [
                        'name' => 'thumbnail_image_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                        'exclude' => [ 'custom' ],
                        'include' => [],
                        'default' => 'large',
                    ]
                );

                $this->add_responsive_control(
                    'title_align', [
                        'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                        'type'    => Controls_Manager::CHOOSE,
                        'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'insut-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                        'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'insut-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                                'title' => esc_html__( 'Right', 'insut-essential' ),
                                'icon'  => 'fa fa-align-right',
                        
                        ],
                        'justify'	 => [

                                'title' => esc_html__( 'Justified', 'insut-essential' ),
                                'icon'  => 'fa fa-align-justify',
                        
                            ],
                        ],
                        'default' => 'left',
                        'selectors' => [
                            '{{WRAPPER}} .tab-content-box'   => 'text-align: {{VALUE}};',
                        
                        ],
                    ]
                );//Responsive control end

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_menu_nav',
            [
            'label' => esc_html__( 'Tab Menu nav', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ] 
        );

                $this->add_control(
                    'nav_menu_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .case-nav li' => 'color: {{VALUE}};',
            
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'nav_menu_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .case-nav li',
                    ]
                );


                $this->add_control(
                    'nav_menu_border_radious',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .case-nav li' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .case-nav' => 'border-radius: {{VALUE}}px;',
                              
                        ],
                    ]
                ); 
            
                $this->add_control(
                    'nav_menu_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'nav_menu_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .case-nav',
                    ]
                );

                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Hover Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
  

                $this->add_control(
                    'nav_menu_active_border_color', [

                        'label'     => esc_html__( 'Active Border Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .case-nav li:hover, .case-nav li.active' => 'border-color: {{VALUE}};',
            
                        ],
                    ]
                );    
                
                $this->add_responsive_control(
                    'nav_menu_item_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .case-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'nav_menu_item_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .case-nav li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

           

              

        $this->end_controls_section();
        $this->start_controls_section('tab_content_title',
            [
            'label' => esc_html__( 'Title', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_content_title_color', [

                'label'     => esc_html__( 'Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .case-meta h4 a' => 'color: {{VALUE}};',

                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_titlr_typho',
                'label'    => esc_html__( ' Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .case-meta h4 a',
            ]
        );

        $this->add_responsive_control(
            'tab_content_title_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .case-meta h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('tab_content_cat',
            [
            'label' => esc_html__( 'Cat', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_content_catr_color', [

                'label'     => esc_html__( 'Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .case-meta p' => 'color: {{VALUE}};',

                ],
            ]
        );

        $this->add_control(
            'tab_content_catr_hvcolor', [

                'label'     => esc_html__( 'Hover Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .case-meta p:hover' => 'color: {{VALUE}};',

                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_cat_typho',
                'label'    => esc_html__( ' Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .case-meta p',
            ]
        );

        $this->add_responsive_control(
            'tab_content_cat_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .case-meta p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
       
        $this->start_controls_section('tab_content_view_more_btn',
            [
            'label' => esc_html__( 'Tab content View more', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'tab_content_view_more__btn_color', [

                    'label'     => esc_html__( 'Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .read-more i' => 'color: {{VALUE}};',

                    ],
                ]
            );


            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_view_more_btn',
                    'label'    => esc_html__( ' Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .read-more i',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'teb_content_view_more_btn_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .read-more',
                ]
            );

            $this->add_control(
                'teb_content_view_more_btn_heading',
                [
                    'label' => esc_html__( 'Hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'teb_content_view_more_btn_background_hover',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .read-more:hover',
                ]
            );

            $this->add_control(
                'teb_content_view_more_border_radious',
                    [
                        'label' => esc_html__( 'Border Radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .read-more' => 'border-radius: {{VALUE}}px;',
                       
                           
                    ],
                ]
            ); 
            $this->add_responsive_control(
                'tab_content_view_more_s_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );
    
            $this->add_responsive_control(
                'teb_content_view_more_s_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();
        $this->start_controls_section('insut__tab_hover_content_boxs',
            [
            'label' => esc_html__( 'Item Box hover', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'box_hv_background_overlay_heading1',
            [
                'label' => esc_html__( 'Overlay', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
               
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_box_ssbackground_hover',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .case-overlay',
            ]
        );
        $this->add_control(
            'box_hv_background_hhheading1',
            [
                'label' => esc_html__( 'Inner Box', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
               
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_boxsssss_background_hover',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .case-meta',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section('insut__tab_content_boxs',
            [
            'label' => esc_html__( 'Item Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_box_background_hover',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .single-case',
            ]
        );

        $this->add_control(
            'teb_content_boxs_border_radious',
                [
                    'label' => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'min'   => 0,
                    'max'   => 200,
                    'step'  => 1,
                    
                    'selectors' => [
                        '{{WRAPPER}} .single-case' => 'border-radius: {{VALUE}}px;',
                      
                       
                ],
            ]
        ); 
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'teb_content_boxs_border_s',
				'label' => esc_html__( 'Border', 'insut-essential' ),
				'selector' => '{{WRAPPER}} .single-case',
			]
		);
        $this->add_responsive_control(
            'tab_content_boxs_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-case' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_boxs_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-case' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('insut_inner_section',
        [
        'label' => esc_html__( 'Inner Content Box', 'insut-essential' ),
        'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );


            $this->add_responsive_control(
                'inner_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .inner-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'inner_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .inner-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'inner_content_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .inner-section',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('insut__main_section',
            [
            'label' => esc_html__( 'Main Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

  
        $this->add_responsive_control(
            'main_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'main_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'main_section_background',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .main-section',
            ]
        );

       $this->end_controls_section();

     
    } //Register control end

    protected function render( ) { 

        $settings         = $this->get_settings();
        $custom_case      = $settings['custom_case'];
        $case             = $settings['case'];
        $cat             = $settings['cat'];
        $custom_case_ids  = $settings['custom_case_ids'];
        $post_count       = $settings['post_count'];
        $post_sort        = $settings['post_sort'];
        $show_more_active = $settings['show_more_active'];
      
        
        $args = array(

            'posts_per_page'   => $post_count,
            'orderby'          => 'post_date',
            'order'            => 'DESC',
            'post_type'        => 'quomodo-case',
            'post_status'      => 'publish',
            'suppress_filters' => false,
        
        );
        
        if(count( $cat) ){
          $args['tax_query'] = array(
            array(
                'taxonomy' => 'case-cat',
                'field'    => 'slug',
                'terms'    => $cat,
            ),
        );
        }

        $args['order'] = $post_sort;

        if($custom_case == 'yes'):

            $ids   = explode(',',$custom_case_ids);
            $args['post__in'] = $ids;

        else:

             if(count($case)){
                $args['post__in'] = $case; 
             }
               
        endif;    
       
        $posts = new \WP_Query( $args );

        if( !count( $cat ) ){
            $cat = $this->get_category();
        }
       
    ?>    
          
        <?php if($settings['style'] == 'style1'): ?>

              <!-- Case Start -->
        <section class="case-section main-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2 col-md-12">
                        <!-- Case Nav Title -->
                        <ul class="case-nav shaf-filter">
                            <li class="active" data-group="all"> <?php echo esc_html__('All','insut'); ?> </li>
                            <?php foreach($cat as $key_slug => $item): ?>
                                <li data-group="<?php echo esc_attr($key_slug); ?>"> <?php echo esc_html($item); ?> </li>
                            <?php endforeach; ?>
                        </ul>
                        <!-- Case Nav Title -->
                    </div>
                </div>
            </div>
            <?php  if($posts->have_posts() ) : ?>
                <div class="container-fluid inner-section">
                    <div class="row shafull-container">
                        <?php

                            while ( $posts->have_posts() ) :
                                $posts->the_post();
                                $terms = get_the_terms($posts->ID, 'case-cat' );
                                $tslugs_arr = [];
                               
                                if ($terms && ! is_wp_error($terms)) :

                                    $tslugs_arr = array();
                                    foreach ($terms as $term) {
                                        $tslugs_arr[] = $term->slug;
                                        $single_cat = $term->name;
                                    }
                                    
                                endif;
                       
                        ?>
                                <!-- Single Case Item -->
                                <div class="col-lg-4 col-md-6 shaf-item" data-groups='<?php echo json_encode($tslugs_arr); ?>'>
                                    <div class="single-case">
                                        <?php if(has_post_thumbnail()): ?>
                                            <img src="<?php echo esc_url(get_the_post_thumbnail_url(null, $settings['thumbnail_image_size_size'])); ?>" alt="<?php the_title_attribute(); ?>">
                                        <?php endif; ?> 
                                        <div class="case-overlay">
                                            <div class="case-meta">
                                                <h4><a href="<?php echo esc_url(get_the_permalink()); ?>"> <?php echo esc_html(get_the_title()); ?> </a></h4>
                                                <?php if($single_cat !=''): ?>
                                                <p class="case-cate"> <?php echo esc_html($single_cat); ?> </p>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($show_more_active): ?>
                                            <a class="read-more" href="<?php echo esc_url(get_the_permalink()); ?>"><i class="icofont-arrow-right"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Case Item -->
                        <?php  

                            endwhile; 
                            wp_reset_postdata();
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>  
        <!-- Case End -->
            
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }

    protected function get_case_list(){
        $_list = [];
        $args = array(
              'numberposts'      => -1,
              'orderby'          => 'post_date',
              'order'            => 'DESC',
              'post_type'        => 'quomodo-case',
              'post_status'      => 'publish',
              'suppress_filters' => false
        );
  
        $services = get_posts($args);
   
        if($services):
         // Loop the posts
           foreach ($services as $feature):
             $_list[$feature->ID] = $feature->post_title; 
           endforeach;
        endif;
  
        return $_list;  
    }

    protected function get_category(){
        $_list = [];
        $terms = get_terms( array( 
            'taxonomy' => 'case-cat',
            'parent'   => 0
        ) );

        if($terms):
            // Loop the posts
              foreach ($terms as $cat):
                $_list[$cat->slug] = $cat->name; 
              endforeach;
           endif;

        return $_list;
    }
}