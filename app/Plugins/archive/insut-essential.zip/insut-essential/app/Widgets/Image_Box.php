<?php
namespace InsutEssential\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class Image_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-image-boxs';
    }

    public function get_title() {
        return esc_html__( 'Insut Image Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-file-image-o";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
        
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

            'block_style', [
                'label'   => esc_html__('Choose Style', 'insut-essential'),
                'type'    => Custom_Controls_Manager::RADIOIMAGE,
                'default' => 'style1',
                'options' => [
                        'style1' => [
                                'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                                'imagelarge' => INSUT_IMG . '/admin/image-box/style1.png',
                                'imagesmall' => INSUT_IMG . '/admin/image-box/style1.png',
                                'width'      => '100%',
                        ],
                        'style2' => [
                            'title'      => esc_html__( 'Style 2', 'insut-essential' ),
                            'imagelarge' => INSUT_IMG . '/admin/image-box/style2.png',
                            'imagesmall' => INSUT_IMG . '/admin/image-box/style2.png',
                            'width'      => '100%',
                        ],

                        'style3' => [
                            'title'      => esc_html__( 'Style 3', 'insut-essential' ),
                            'imagelarge' => INSUT_IMG . '/admin/image-box/style3.png',
                            'imagesmall' => INSUT_IMG . '/admin/image-box/style3.png',
                            'width'      => '100%',
                        ],

                        'style4' => [
                            'title'      => esc_html__( 'Style 4', 'insut-essential' ),
                            'imagelarge' => INSUT_IMG . '/admin/image-box/style4.png',
                            'imagesmall' => INSUT_IMG . '/admin/image-box/style4.png',
                            'width'      => '100%',
                        ],

                       

                       

            ],

            ]
        ); 

       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Image Box settings', 'insut-essential'),
            ]
        );
      
        $this->add_control(
			'image1',
			[
				'label' => esc_html__( 'Choose Image ', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
		);
        $this->end_controls_section();

        
  
        //Image Style Section
		$this->start_controls_section(
			'section_image_style', [
				'label' => esc_html__( 'Image one', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
                $this->add_responsive_control(
                    'section_thumb_image_radius',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                        
                            'selectors' => [
                                '{{WRAPPER}} .big-img' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .ab-thumb img' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .about-us-thumb img' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .details-thumb img' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 

                $this->add_responsive_control(
                    'image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .big-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .ab-thumb img ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .about-us-thumb img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .details-thumb img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'image_section_padding',
                    [
                        'label'      => esc_html__( 'padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .big-img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .ab-thumb img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .about-us-thumb img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .details-thumb img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

               
        $this->end_controls_section();

        $this->start_controls_section(
			'section_shape_image_style', [
				'label' => esc_html__( 'Shape Image / Icon', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

               
                $this->add_control(
                    'border_shape_shape_icon_a_color',
                    [
                        'label' => esc_html__('Border Bottom Shape Color', 'insut-essential'),
                        'type'  => Controls_Manager::COLOR,
                        'condition' => [ 'block_style' => ['style4'] ],
                        'selectors' => [
                        
                            '{{WRAPPER}} .details-thumb:after'    => 'border-left-color: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_bottm_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'condition' => [ 'block_style' => ['style4'] ],
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .details-thumb:after' => 'left: {{SIZE}}{{UNIT}};',
                     
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_bottom_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'condition' => [ 'block_style' => ['style4'] ],
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .details-thumb:after' => 'bottom: {{SIZE}}{{UNIT}};',
                    
                           
                        ],
                    ]
                );
               
                $this->add_control(
                    'shape_icon_a_color',
                    [
                        'label' => esc_html__('color', 'insut-essential'),
                        'type'  => Controls_Manager::COLOR,
                        'condition' => [ 'block_style' => ['style2','style3','style4'] ],
                        'selectors' => [
                            '{{WRAPPER}} .ab-icon i'    => 'color: {{VALUE}};',
                            '{{WRAPPER}} .ab-icon-two i'    => 'color: {{VALUE}};',
                            '{{WRAPPER}} .ser-post-icon i'    => 'color: {{VALUE}};',
                        
                        ],
                    ]
                ); 
        
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'shape_icon_typography',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .ab-icon i,{{WRAPPER}} .ab-icon-two i,{{WRAPPER}} .ser-post-icon i',
                        'condition' => [ 'block_style' => ['style2','style3','style4'] ],
                    ]
                ); 
              
                $this->add_responsive_control(
                    'shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .fact-thumb:after' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ser-post-icon' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .fact-thumb:after' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ser-post-icon' => 'left: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .fact-thumb:after' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ser-post-icon' => 'bottom: {{SIZE}}{{UNIT}};',
                           
                        ],
                    ]
                );
               
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shapebackground',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                     
                        'selector' => '{{WRAPPER}} .ser-post-icon ,{{WRAPPER}} .ab-icon-two:after,{{WRAPPER}} .fact-thumb:after,{{WRAPPER}} .ab-icon:after,{{WRAPPER}} .ab-thumb:after',
                    ]
                );
                $this->add_control(
                    'icon_backhround_heading',
                    [
                       'label'     => esc_html__( 'Icon background', 'insut-essential' ),
                       'type'      => \Elementor\Controls_Manager::HEADING,
                       'separator' => 'after',
                       'condition' => [ 'block_style' => ['style3','style4'] ],
                    ]
                 );
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'condition' => [ 'block_style' => ['style3','style4'] ],
                        'selector' => '{{WRAPPER}} .ab-icon-two, {{WRAPPER}} .ser-post-icon:after,{{WRAPPER}} .ser-post-icon',
                    ]
                );

               
                $this->add_responsive_control(
                    'shape_imageopacity',
                        [
                            'label' => esc_html__( 'Opacity', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 1,
                            'step'  => 0.1,
                           
                            'selectors' => [
                                
                                '{{WRAPPER}} .fact-thumb:after' => 'opacity: {{VALUE}};',
                                '{{WRAPPER}} .ab-icon' => 'opacity: {{VALUE}};',
                                '{{WRAPPER}} .ab-icon-two' => 'opacity: {{VALUE}};',
                                '{{WRAPPER}} .ser-post-icon' => 'opacity: {{VALUE}};',
                        ],
                    ]
                ); 
    
                $this->add_responsive_control(
                    'shape_image_section_height',
                    [
                        'label'      => esc_html__( 'Height', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .fact-thumb:after' => 'height: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon' => 'height: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'height: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'height: {{SIZE}}{{UNIT}};',
                           
                        ],
                    ]
                );
                $this->add_responsive_control(
                    'shape_image_section_width',
                    [
                        'label'      => esc_html__( 'Width', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .fact-thumb:after' => 'width: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon' => 'width: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .ab-icon-two' => 'width: {{SIZE}}{{UNIT}};',
                           
                        ],
                    ]
                );
        $this->end_controls_section();
       
        
        $this->start_controls_section('appscred__main_section',
                [
                'label' => esc_html__( 'Main Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

          
                $this->add_responsive_control(
                    'main_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                        
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'main_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_section_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		
     
    ?>
        <?php if( $settings['block_style'] =='style1' ): ?> 

             <!-- Fun Fact Image start -->
             <div class="fact-thumb main-section">
                <?php if($settings['image1']['url'] !=''): ?>
                    <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                <?php endif; ?>
            </div>
            <!-- Fun Fact Image End -->

        <?php endif; ?>
        <?php if( $settings['block_style'] =='style2' ): ?> 
            <div class="ab-thumb main-section">
                <?php if($settings['image1']['url'] !=''): ?>
                    <img src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                <?php endif; ?>
                <div class="ab-icon">
                   
                    <?php if( $settings['icon']['value'] == '' ): ?>
                        <i class="insut-Icon">
                            <span class="path3"></span>
                        </i>
                    <?php else: ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>
        <?php if( $settings['block_style'] =='style3' ): ?> 
            <div class="about-us-thumb main-section">
                
                <?php if($settings['image1']['url'] !=''): ?>
                    <img src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                <?php endif; ?>
                   
                <div class="ab-icon-two">
                
                    <?php if( $settings['icon']['value'] == '' ): ?>
                        <i class="icofont-home"></i>
                    <?php else: ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>

                </div>

            </div>
        <?php endif; ?>
        <?php if( $settings['block_style'] =='style4' ): ?> 
            <div class="details-thumb main-section">
               <?php if($settings['image1']['url'] !=''): ?>
                    <img src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                <?php endif; ?>
                <div class="ser-post-icon">
                   
                    <?php if( $settings['icon']['value'] == '' ): ?>
                        <i class="insut-Logo"> <span class="path3"></span> </i>
                    <?php else: ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>
    
      
    <?php  

    }
    
    protected function _content_template() { }
}