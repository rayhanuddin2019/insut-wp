<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Icon_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-icon-box';
    }

    public function get_title() {
        return esc_html__( 'Insut Icon Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'insut-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                    'imagelarge' => INSUT_IMG . '/admin/icon-box/style1.png',
                    'imagesmall' => INSUT_IMG . '/admin/icon-box/style1.png',
                    'width'      => '100%',
               ],

               'style2' => [
                'title'      => esc_html__( 'Style 2', 'insut-essential' ),
                'imagelarge' => INSUT_IMG . '/admin/icon-box/style2.png',
                'imagesmall' => INSUT_IMG . '/admin/icon-box/style2.png',
                'width'      => '100%',
             ],

           ],

         ]
       ); 
       $this->end_controls_section();
       


        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Content settings', 'insut-essential'),
            ]
        );
       
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
     
        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );
        
       
        $repeater->add_responsive_control(
			'show_shape',
			[
				'label' => esc_html__( 'Show Right Shape', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block'  => esc_html__( 'Show', 'insut-essential' ),
					'none' => esc_html__( 'Hide', 'insut-essential' ),
					
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}:after' => 'display: {{VALUE}};',
                ],
			]
		);
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
   
     
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'left',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .sevices-item' => 'text-align: {{VALUE}};',
                    

				],
			]
        );//Responsive control end

        $this->end_controls_section();
      
        
        
       

        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Title color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .title' => 'color: {{VALUE}};',
				],
			]
        );

        $this->add_control(
			'title_hover_color', [

				'label'     => esc_html__( 'Hover color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .title:hover' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .why-choose-box:hover .title' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .title',
            ]
        );
        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

    
        $this->start_controls_section('box_shape_section',
                [
                    'label' => esc_html__( 'Shape', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                     'condition' => [ 'block_style' => ['style1'] ],
                ]
        );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_border_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .icon-box-01:after',
                    ]
                );
                
                $this->add_responsive_control(
                    'shape_border_left_width',
                    [
                        'label' => esc_html__( 'Width', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -100,
                                'max' => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .icon-box-01:after' => 'width: {{SIZE}}{{UNIT}};',
                
                    
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_border_left_height',
                    [
                        'label' => esc_html__( 'Height', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .icon-box-01:after' => 'height: {{SIZE}}{{UNIT}};',
                
                    
                        ],
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('box_icon_section',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control(
                'icon_color', [

                    'label'     => esc_html__( 'Icon color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .icon-box-01 i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .why-choose-box i' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'icon_hover_color', [

                    'label'     => esc_html__( 'Hover color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .icon-box-01:hover i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .why-choose-box:hover i' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'icon_typho',
                    'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .icon-box-01 i,{{WRAPPER}} .why-choose-box i',
                ]
            );
            $this->add_responsive_control(
                'icon_position_left',
                [
                    'label' => esc_html__( 'Left Position', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -100,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .icon-box-01 i' => 'left: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .why-choose-box i' => 'left: {{SIZE}}{{UNIT}};',
               
                
                    ],
                ]
            );
            $this->add_responsive_control(
                'icon_position_top',
                [
                    'label' => esc_html__( 'Top Position', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -100,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .icon-box-01 i' => 'top: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .why-choose-box i' => 'top: {{SIZE}}{{UNIT}};',
               
                
                    ],
                ]
            );

            $this->add_control('icon_sbox_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style2'] ],
                'selectors' => [
                  
                    '{{WRAPPER}} .why-choose-box i' => 'background: {{VALUE}};',
                      
                    ],
                ]
            );
        $this->end_controls_section();
    
        
       
        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control('box_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  
                    '{{WRAPPER}} .icon-box-01' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .why-choose-box' => 'background: {{VALUE}};',
                      
                    ],
                ]
            );

            $this->add_control(
                'insut_hover_active',
                [
                    'label' => esc_html__( 'Hover Active', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Enable', 'insut-essential' ),
                    'label_off' => esc_html__( 'Disable', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default' => '',
                ]
            );

            $this->add_control('boxss_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style2'] ],
                'selectors' => [
                  
                    
                    '{{WRAPPER}} .why-choose-box:hover' => 'background: {{VALUE}};',
                      
                    ],
                ]
            );
          
            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'     => 'box_border',
                    'label'    => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .icon-box-01 , {{WRAPPER}} .why-choose-box',
                ]
            );


            $this->add_responsive_control(
                '_box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .icon-box-01' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .why-choose-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                      
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        
                        '{{WRAPPER}} .icon-box-01' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .why-choose-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                    ],
                ]
            );

            $this->add_responsive_control(
                'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .icon-box-01' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .why-choose-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                         
                        ],
                    ]
            );

        $this->end_controls_section();
        // main section
        $this->start_controls_section('appscred_box__main_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'block_style' => ['style1'] ],
            ]
        );
   
         $this->add_group_control(
           \Elementor\Group_Control_Background::get_type(),
           [
              'name'     => 'main_section_background',
              'label'    => esc_html__( 'Background', 'insut-essential' ),
              'types'    => [ 'classic', 'gradient', 'video' ],
              'selector' => '{{WRAPPER}} .box-wrapper ',
           ]
        );
       
       $this->add_responsive_control(
        'main_box_margin',
           [
              'label'      => esc_html__( 'Margin', 'insut-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .box-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            
              ],
           ]
        );

        $this->add_responsive_control(
           'main_box_padding',
           [
              'label'      => esc_html__( 'Padding', 'insut-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .box-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
              ],
           ]
        );

     $this->end_controls_section();

    
    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
		$list     = $settings['list'];
    
    ?>
   
     <?php if( $settings['block_style'] == 'style1' ): ?>
        <div class="box-wrapper ">
             <?php foreach($list as $item): ?>
                <div class="icon-box-01 elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?> icon-box-shape inner-item">
                   
                    <?php if($item['list_icon']['value'] == ''): ?>
                        <i class="insut-Icon">
                            <span class="path3"></span>
                        </i>
                    <?php else: ?>    
                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>    
                   
                    <h5 class="title"> <?php echo esc_html( $item['list_title'] ); ?> </h5>
                </div>
             <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if( $settings['block_style'] == 'style2' ): ?>
      
           <?php foreach($list as $item): ?>
                <div class="why-choose-box <?php echo esc_attr($settings['insut_hover_active']=='yes'?'with-bg':''); ?>">
                    
                    <?php if($item['list_icon']['value'] == ''): ?>
                        <i class="insut-Icon">
                            <span class="path3"></span>
                        </i>
                    <?php else: ?>    
                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>
                    <h4 class="title"> <?php echo esc_html( $item['list_title'] ); ?> </h4>
                </div>
            <?php endforeach; ?>
      
           
      <?php endif; ?>
   

    <?php  

    }
    
    protected function _content_template() { }
}