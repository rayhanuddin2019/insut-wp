<?php
namespace InsutEssential\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class Image_Box2 extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-shape-image-boxs';
    }

    public function get_title() {
        return esc_html__( 'Insut Shape Image Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-file-image-o";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
        
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

            'block_style', [
                'label'   => esc_html__('Choose Style', 'insut-essential'),
                'type'    => Custom_Controls_Manager::RADIOIMAGE,
                'default' => 'style1',
                'options' => [
                        'style1' => [
                                'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                                'imagelarge' => INSUT_IMG . '/admin/image-box/style5.png',
                                'imagesmall' => INSUT_IMG . '/admin/image-box/style5.png',
                                'width'      => '100%',
                        ],
        
            ],

            ]
        ); 

       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Image Box settings', 'insut-essential'),
            ]
        );
        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( ' Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
        $this->add_control(
			'image1',
			[
				'label' => esc_html__( 'Choose Image ', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Choose Image ', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'image3',
			[
				'label' => esc_html__( 'Choose Image ', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

      
        $this->end_controls_section();

        $this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .ab-years' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_control(
                    'title_hover_color', [

                        'label'     => esc_html__( 'Heighlight color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .ab-years span ' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .ab-years',
                    ]
                );

                $this->add_responsive_control(
                    'texture_title_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .ab-years' => 'top: {{SIZE}}{{UNIT}};',
                          
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'texture_title_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .ab-years' => 'left: {{SIZE}}{{UNIT}};',
                         
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'texture_title_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .ab-years' => 'bottom: {{SIZE}}{{UNIT}};',
                          
                           
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'texture_title_section_position_right',
                    [
                        'label'      => esc_html__( 'Position right', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .ab-years' => 'right: {{SIZE}}{{UNIT}};',
                          
                           
                        ],
                    ]
                );

        $this->end_controls_section();
  
        //Image Style Section
		$this->start_controls_section(
			'section_image_style', [
				'label' => esc_html__( 'Image 1', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
                $this->add_responsive_control(
                    'image_one1_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-01' => 'top: {{SIZE}}{{UNIT}};',
                        
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one1_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-01' => 'left: {{SIZE}}{{UNIT}};',
                        
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one1_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-01' => 'bottom: {{SIZE}}{{UNIT}};',
                        
                        
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one1_section_position_right',
                    [
                        'label'      => esc_html__( 'Position right', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-01' => 'right: {{SIZE}}{{UNIT}};',
                        
                        
                        ],
                    ]
                ); 

                $this->add_responsive_control(
                    'image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-thumb-01' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        
               
        $this->end_controls_section();

         //Image Style Section
		$this->start_controls_section(
			'section_image2_style', [
				'label' => esc_html__( 'Image 2', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
                $this->add_responsive_control(
                    'image_one12_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-02' => 'top: {{SIZE}}{{UNIT}};',
                        
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one12_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-02' => 'left: {{SIZE}}{{UNIT}};',
                        
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one12_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-02' => 'bottom: {{SIZE}}{{UNIT}};',
                        
                        
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'image_one12_section_position_right',
                    [
                        'label'      => esc_html__( 'Position right', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .ab-thumb-02' => 'right: {{SIZE}}{{UNIT}};',
                        
                        
                        ],
                    ]
                ); 

                $this->add_responsive_control(
                    'image2_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-thumb-02' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        
               
        $this->end_controls_section();

        $this->start_controls_section(
			'section_image3_style', [
				'label' => esc_html__( 'Image 3', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
              
                $this->add_responsive_control(
                    'image3_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-thumb-03' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        
               
        $this->end_controls_section();
        
       
        
        $this->start_controls_section('appscred__main_section',
                [
                'label' => esc_html__( 'Main Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

          
                $this->add_responsive_control(
                    'main_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                        
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'main_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_section_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
        $title     = $settings['title'];
	    $title_1   = str_replace(['{', '}'], ['<span>', '</span>'], $title);
     
    ?>
        <?php if( $settings['block_style'] =='style1' ): ?> 

            <div class="about-area-thumb main-section">
                 <?php if($settings['image1']['url'] !=''): ?>   
                    <div class="ab-thumb-01">
                        <img src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image 1','insut-essential'); ?>">
                    </div>
                <?php endif; ?>
                <?php if($settings['image2']['url'] !=''): ?>
                    <div class="ab-thumb-02">
                        <img src=" <?php echo esc_url($settings['image2']['url']); ?> " alt="<?php echo esc_attr__('Image 3','insut-essential'); ?>">
                    </div>
                <?php endif; ?>
                <?php if($settings['image3']['url'] !=''): ?>
                    <div class="ab-thumb-03">
                        <img src=" <?php echo esc_url($settings['image3']['url']); ?> " alt="<?php echo esc_attr__('Image 2','insut-essential'); ?>">
                    </div>
                <?php endif; ?>
                <h1 class="ab-years"> <?php echo insut_kses($title_1); ?> </h1>
            </div>

        <?php endif; ?>
      
   
    
      
    <?php  

    }
    
    protected function _content_template() { }
}